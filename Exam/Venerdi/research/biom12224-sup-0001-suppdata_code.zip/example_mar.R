# stationary version with informative dropout
source("LM_dropout_biv.R")
require(xtable)
library(JM)
data(pbc2)
sta = 1      # stationary transition matrix
miss = FALSE # TRUE for NMAR, FALSE for MAR
k1max = 3    # maximum number of latent states for U
k2max = 3    # maximum number of latent states for V
file_name = "example_mar.RData"   # file to save results
tol = 10^-8  # tolerance level for the first part

# outcome data (312 subjects, 16 time occasions, 2 variables)
n = 312                   # sample size
s = 16                    # number of occasions
Y = array(NA,c(n,16,2))   # response variables
X = array(NA,c(n,16,8))   # covariates for the resopnse varaibles
D = 1*(!pbc2.id$status=="alive")
id = pbc2$id
for(i in 1:n){
# bilirubin
	resp=pbc2$serBilir[id==i]
	l=length(resp)
	Y[i,1:l,1]=resp
# edema
	resp=ifelse(pbc2$edema[id==i]=="No edema",0,1)
	Y[i,1:l,2]=resp
# covariates
	X[i,1:l,1] = 1*(pbc2.id$drug[i]=="D-penicil")
	X[i,1:l,2] = pbc2.id$age[i]-mean(pbc2.id$age)
	X[i,1:l,3] = 1*(pbc2.id$sex[i]=="female")
	X[i,1:l,4] = pbc2.id$albumin[i]
	X[i,1:l,5] = log(pbc2.id$alkaline[i])
	X[i,1:l,6] = log(pbc2.id$SGOT[i])
	X[i,1:l,7] = pbc2$year[id==i]
	X[i,1:l,8] = X[i,1:l,1]*X[i,1:l,7]
}
#log-transformations
Z = X                   # covariate for the missing process
Y[,,1] = log(Y[,,1])

# estimate model
its = matrix(NA,k1max,k2max)   # number of attemps for each model
nps = its                      # number of parameters for each model
lks = its                      # maximum log-likelihood for each model
bics = its                     # BIC for each model
itbests = its                  # number of solutions equal to best solution for each model
LK = array(NA,c(k1max,k2max,1000))     # parameter estimates for the first response and each model
outlist = vector("list",k1max*k2max)   # final output for each model
it0 = 0
for(k2 in 1:k2max){
	for(k1 in 1:k1max){
		it0 = it0+1
		out = try(est_LM_dropout(Y,X,Z,k1=k1,k2=k2,miss=miss,sta=sta,DD=D,tol=tol))
		print(out$be1)
		LK[k1,k2,1] = out$lk
		if(!inherits(out,"try-error")){
            it = 1
            its[k1,k2] = 1; itbests[k1,k2] = 1
			if(k1>1 || k2>1){
				flag1 = TRUE
                while(flag1){
                    it = it+1
					outr = try(est_LM_dropout(Y,X,Z,k1=k1,k2=k2,miss=miss,start=1,sta=sta,DD=D,tol=tol))
					if(!inherits(outr,"try-error")){
						print(out$be1)
						if(outr$lk>out$lk) out=outr
						LK[k1,k2,it] = outr$lk
					}
					flag1 = FALSE
					if(k1>1) if(!is.na(lks[k1-1,k2])) if(out$lk<max(lks[1:(k1-1),1:k2],na.rm=T)) flag1 = TRUE
					if(k2>1) if(!is.na(lks[k1,k2-1])) if(out$lk<max(lks[1:k1,1:(k2-1)],na.rm=T)) flag1 = TRUE
					if(it<1+10*(out$np-nps[1])) flag1 = TRUE
		            its[k1,k2]=it
					tmp = LK[k1,k2,]; tmp = tmp[!is.na(tmp)]
					itbests[k1,k2] = sum(max(tmp)-tmp<0.01)
                    save.image(file_name)
				}
			}
			lks[k1,k2]=out$lk
			bics[k1,k2]=out$bic
			nps[k1,k2]=out$np
		}
		if(k1==1 & k2==1){
			outbest = out
		}else{
			if(out$bic<outbest$bic) outbest=out
		}
        print(its)
        print(itbests)
		print(lks)
		print(nps)
		print(bics)
		out = try(est_LM_dropout(Y,X,Z,k1=k1,k2=k2,miss=miss,
			      be1=c(out$al1u[-1],out$al1v[-1],out$be1),
	              be2=c(out$al2u[-1],out$al2v[-1],out$be2),
	              de=c(out$gau[-1],out$gav[-1],out$de),
	              la=out$la,piv=out$piv,Pi=out$Pi,si2=out$si2,sta=sta,se_out=TRUE,DD=D))
		outlist[[it0]] = out
		save.image(file_name)
	}
}
