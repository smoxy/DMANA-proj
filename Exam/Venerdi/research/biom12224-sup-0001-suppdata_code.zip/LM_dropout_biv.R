#-----------------------------------------------------------------------------------------------
dyn.load("BWforback.so")
dyn.load("BWforback2.so")
require(MASS)
#-----------------------------------------------------------------------------------------------
est_LM_dropout <- function(Y,X,Z,k1,k2,start=0,tol=10^-10,miss=FALSE,sta=0,be1=NULL,si2=NULL,
be2=NULL,de=NULL,la=NULL,piv=NULL,Pi=NULL,se_out=FALSE,DD=NULL,maxit=1000){
	
# EM algorithm to estimate mixed latent Markov models with possible (informative) dropout in the case 
# of two response variables (the first is continuous, the second is binary)
# 
# *** F. Bartolucci (University of Perugia, IT) and A. Farcomeni (University of Rome 1, IT) ***
# 
# INPUT:
# Y      = matrix of the responses - size n x T x 2 (n = sample size, T = number of time occasions)
# X      = matrix of the covariates affecting the longitudinal process - size n x T x ncX 
#          (ncX = number of X covariates)
# Z      = matrix of the covariates affecting the missingness data mechanism - size n x T x ncZ 
#          (ncZ = number of Z covariates)
# k1     = number of support points of the latent variable U (time-fixed) 
# k2     = number of support points of the latent variable V (time-varying according to a 
#          first-order Markov chain) 
# start  = type of initialization (0 = deterministic, 1 = random - default is 0)
# tol    = relative tolerance for the convergence of the algorithm (default is 10^-10)
# miss   = indicator for the presence of informative missing values (FALSE = ignorable dropout, 
#          TRUE = not ignorable dropout - default is FALSE)
# sta    = type of constraint on the hidden transition matrix (0 = standard model, 1 = stationary, 
#          2 = same transition probability, 3 = stationary with same off-diagonal elements constant in
#          each row - default is 0)
# be1    = initial value for the regression coefficients of X on the 1st response variable
# si2    = initial value for the variance for the regression of X on the 1st response variable
# be2    = initial value for the logistic regression coefficients of X on the 2nd response variable
# de     = initial value for the logistic regression coefficients of Z on the missing data indicator
# la     = initial value for the mass probabilities of the latent variable U
# piv    = initial value for the initial probability vector for the latent variable V
# Pi     = initial value for the transition probability matrix for the latent variable V
# se_out = to require the computation of the standard errors (default is FALSE)
# DD     = vector of 1s and 0s to indicate drop-out or not (default is NULL)
# maxit  = maximum number of iterations
#
# OUTPUT:
# 
# al1u  = estimate of the support points for the latent variable U on the 1st response variable 
# al1v  = estimate of the support points for the latent variable V on the 1st response variable
# be1   = estimate of the regression coefficients of X on the 1st response variable 
# al2u  = estimate of the support points for the latent variable U on the 2nd response variable
# al2v  = estimate of the support points for the latent variable V on the 2nd response variable
# be2   = estimate of the logistic regression coefficients of X on the 2nd response variable
# si2   = estimate of the variance for the regression coefficients of X on the 1st response variable
# gau   = estimate of the support points for the latent variable U on the missing data indicator
# gav   = estimate of the support points for the latent variable V on the missing data indicator
# de    = estimate of the logistic regression coefficients of Z on the missing data indicator
# la    = estimate of the mass probabilities of the latent variable U
# piv   = estimate of the initial probability vector for the latent variable V
# Pi    = estimate of the transition probability matrix for the latent variable V
# lk    = log-likelihood value at convergence
# np    = number of free parameters
# bic   = value of BIC index
# W     = matrix of posterior probabilities
# sebe1 = standard errors for be1 (if required by se_out=TRUE)
# sebe2 = standard errors for be2 (if required by se_out=TRUE)
# sede  = standard errors for de (if required by se_out=TRUE)

# preliminaries
dimY = dim(Y)
n = dimY[1]; TT = as.integer(dimY[2])
if(is.null(X)) ncX = 0 else ncX = dim(X)[3]
nbe = k1+k2-1+ncX
if(miss){
	if(is.null(Z)) ncZ = 0 else ncZ = dim(Z)[3]
	nde=k1+k2-1+ncZ
}else{
	nde = 0
}
Y1 = Y[,,1]; Y20 = 1-Y[,,2]; Y21 = Y[,,2]
k2 = as.integer(k2)
Tv = rep(0,n)  # number of observation per sample unit
for(i in 1:n){
	Tv[i] = max(which(apply(!is.na(Y[i,,]),1,all)))
	if(Tv[i]<TT){
		Y1[i,(Tv[i]+1):TT] = 0
		Y20[i,(Tv[i]+1):TT] = 0
		Y21[i,(Tv[i]+1):TT] = 0
	}
}
Tv = as.integer(Tv)
if(miss){
	D1 = matrix(0,n,TT)
	for(i in 1:n) D1[i,Tv[i]] = 1
}

# design matrices (first elements of the 1' dimension are for the latent variables)
XX = array(0,c(nbe,n,TT,k1,k2))
for(u in 1:k1){
	du = rep(0,k1-1); if(u>1) du[u-1] = 1
	for(v in 1:k2){
		dv = rep(0,k2-1); if(v>1) dv[v-1] = 1
		for(i in 1:n) for(t in 1:TT) XX[,i,t,u,v] = c(du,dv,1,X[i,t,]) 
	}	
} 
for(i in 1:n) if(Tv[i]<TT) XX[,i,(Tv[i]+1):TT,,] = 0
if(miss){
	ZZ = array(0,c(nde,n,TT,k1,k2))
	for(u in 1:k1){
		du = rep(0,k1-1); if(u>1) du[u-1] = 1
		for(v in 1:k2){
			dv = rep(0,k2-1); if(v>1) dv[v-1] = 1
			for(i in 1:n) for(t in 1:TT) ZZ[,i,t,u,v] = c(du,dv,1,Z[i,t,]) 
		}	
	} 
	for(i in 1:n) if(Tv[i]<TT) ZZ[,i,(Tv[i]+1):TT,,] = 0
}

# preliminaries
inibe1 = is.null(be1)
inibe2 = is.null(be2)
inide = is.null(de)

# intial parameters
if(is.null(si2)){
	si20 = var(as.vector(Y[,,1]),na.rm=T)
	si0 = sqrt(si20)
}
if(start==0){
	if(inibe1){
		if(k1+k2==2){
	    	be1 = c(mean(Y[,,1],na.rm=T),rep(0,ncX))
		}else{
	    	out1 = est_LM_dropout(Y,X,Z,1,1,start,tol,miss)
	    	be10 = out1$be1[2:(ncX+1)]
	    	E = matrix(NA,n,TT)
	    	for(i in 1:n) for(t in 1:Tv[i]) E[i,t] = Y[i,t,1]-X[i,t,]%*%be10-out1$be1[1]
			em = rowMeans(E,na.rm=T)
			if(k1==1) em = em*0
		  	if(k1==1){
		    	if(inibe1) be1 = NULL
		  		mbe = 0
		  	}else{
		    	if(inibe1){
		    		be1 = quantile(em,probs=(1:k1)/(k1+1))
		    		mbe = be1[1]; be1 = be1[-1]-be1[1]
		    	}
	  		}
		  	if(k2>1){
		  		D = E-em%o%rep(1,TT)
		  		tmp = quantile(as.vector(D),probs=(1:k2)/(k2+1),na.rm=T)
	    		if(inibe1){
	    			mbe = mbe+tmp[1]; tmp = tmp[-1]-tmp[1]
	    			be1 = c(be1,tmp)
				}
		  	}
	    	if(inibe1) be1 = c(be1,out1$be1[1]+mbe,out1$be1[-1])
	   	}
	}
	if(inibe2){
	   	if(k1+k2==2){
			be2 = rep(0,nbe)
			mm = mean(Y[,,2],na.rm=T)
			be2[k1+k2-1] = log(mm/(1-mm))
		}else{
			be2 = c(rep(0,k1+k2-2),out1$be2)
		}
	}
	if(is.null(la)) la = rep(1,k1)/k1
	if(is.null(piv)) piv = rep(1,k2)/k2
	if(is.null(Pi)) Pi = matrix(1,k2,k2)/k2
	if(miss & inide){
		if(k1+k2==2){
			de = rep(0,nde)
		}else{
			de = c(rep(0,k1+k2-2),out1$de)
		}
	}
	if(is.null(si2)) if(k1+k2==2) si2 = si20 else si2 = out1$si2
}else{
   	if(k1+k2>2) out1 = est_LM_dropout(Y,X,Z,1,1,start=0,tol,miss)
   	si0 = sqrt(out1$si2)
   	if(inibe1){
	  	if(k1==1){
  			be1 = NULL; mbe1 = 0 
  		}else{
 			be1 = rnorm(k1,0,si0); mbe1 = be1[1]; be1 = be1[-1]-be1[1]
  		}
  		if(k2>1){
  			tmp = rnorm(k2,0,si0); mbe1 = mbe1+tmp[1]; be1 = c(be1,tmp[-1]-tmp[1])
  		}
		be1 = c(be1,out1$be1[1]+mbe1,out1$be1[-1])#*runif(ncX,0.9,1.1))
	}
    if(inibe2){
    	if(k1==1){
    		be2 = NULL; mbe2 = 0
    	}else{
   			be2 = rnorm(k1); mbe2 = be2[1]; be2 = be2[-1]-be2[1]
    	}
    	if(k2>1){
  			tmp = rnorm(k2); mbe2 = mbe2+tmp[1]; be2 = c(be2,tmp[-1]-tmp[1])    		
    	}
		be2 = c(be2,out1$be2[1]+mbe2,out1$be2[-1])#*runif(ncX,0.9,1.1))
	}
	if(is.null(si2)) si2 = out1$si2
	if(is.null(la)){la = runif(k1); la = la/sum(la)}
	if(is.null(piv)){piv = rep(1,k2); piv = piv/sum(piv)}
	if(is.null(Pi)){Pi = matrix(runif(k2^2),k2,k2); Pi = Pi/rowSums(Pi)}
	if(sta==1 | sta==3){
		tmp = Pi
		for(it in 1:1000) tmp = tmp%*%Pi
		piv = colMeans(Pi); piv = piv/sum(piv)
	}
	if(miss & inide){
		if(k1==1){
    		de = NULL; mde = 0
    	}else{
   			de = rnorm(k1); mde = de[1]; de = de[-1]-de[1]
    	}
    	if(k2>1){
  			tmp = rnorm(k2); mde = mde+tmp[1]; de = c(de,tmp[-1]-tmp[1])    		
    	}
		de = c(de,out1$de[1]+mde,out1$de[-1])#*runif(ncZ,0.9,1.1))
	}
	if(sta==2) ga = runif(1)/k2
}
ga = NULL
if(k2>1){
	if(sta==1) for(v in 1:k2) ga = c(ga,log(Pi[v,-v]/Pi[v,v]))
	if(sta==3){
		for(v in 1:(k2-1)) ga = c(ga,log(Pi[v,v+1]/Pi[v,v]))
		ga = c(ga,log(Pi[k2,k2-1]/Pi[k2,k2]))
	}
}
# confrom matrices
	XXv = array(XX,c(nbe,n*TT,k1,k2))
	XXtv = aperm(XXv,c(2,1,3,4))
	if(miss){
		ZZv = array(ZZ,c(nde,n*TT,k1,k2))
		ZZtv = aperm(ZZv,c(2,1,3,4))
		D1v = as.vector(D1)
	}
	Y1v = as.vector(Y1)
	Y21v = as.vector(Y21)
	Y20v = as.vector(Y20)
# compute likelihood
si = sqrt(si2)
Phi = array(0,c(n,TT,k1,k2))
Pv = array(0,c(n*TT,k1,k2))
for(u in 1:k1) for(v in 1:k2) Pv[,u,v] = expit(t(XXv[,,u,v])%*%be2)
Mu = apply(XX*be1,2:5,sum); P = expit(apply(XX*be2,2:5,sum)); Q = 1-P
for(u in 1:k1) for(v in 1:k2) Phi[,,u,v] = dnorm(Y1v,Mu[,,u,v],si)*(Y21*P[,,u,v]+Y20*Q[,,u,v])
if(miss){
	Pmv = array(0,c(n*TT,k1,k2))
	for(u in 1:k1) for(v in 1:k2) Pmv[,u,v] = expit(ZZtv[,,u,v]%*%de)
	Pm = array(Pmv,c(n,TT,k1,k2))
	if(is.null(DD)){
		Pm[Tv==TT,TT,,] = 1
	}else{
		for(i in 1:n) if(DD[i]==0) Pm[i,Tv[i],,] = 1
	}
	Pmv = array(Pm,c(n*TT,k1,k2))
	Qm = 1-Pm
}
Fc1 = matrix(0,n,k1); PP1 = array(0,c(n,k1,k2,TT)); PP2 = array(0,c(n,k1,k2,k2))
for(i in 1:n) for(u in 1:k1){
	if(miss){
		o = .Fortran("BWforback2", Tv[i], k2, t(Phi[i,1:Tv[i],u,]), t(Pm[i,1:Tv[i],u,]), piv, Pi, lk=0,
		             Pp1=matrix(0,k2,Tv[i]), Pp2=array(0,c(k2,k2,Tv[i])))
	}else{
		o = .Fortran("BWforback", Tv[i], k2, t(Phi[i,1:Tv[i],u,]), piv, Pi, lk=0, Pp1=matrix(0,k2,Tv[i]),
	    			 Pp2=array(0,c(k2,k2,Tv[i])))
	}	
    Fc1[i,u] = exp(o$lk); PP1[i,u,,1:Tv[i]] = o$Pp1
    if(k2>1) PP2[i,u,,] = apply(o$Pp2,c(1,2),sum) 

}
if(k1==1){
  Fj1 = Fc1; fm = Fj1
}else{
  Fj1 = Fc1%*%diag(la)
  fm = rowSums(Fj1)
}
if(min(fm)<10^-300) print("units with no likelihood!")
fm = pmax(fm,10^-300)
lk = sum(log(fm))

# iterate until convergence
it = 0; lko = -Inf
cat("starting values      = ",start,"\n")
cat("stationary           = ",1*sta,"\n")
cat("n.latent classes (U) = ",k1,"\n")
cat("n.latent states (V)  = ",k2,"\n")
cat("tolerance level      = ",tol,"\n")
cat(" |-------------|-------------|-------------|-------------|\n");
cat(" |     step    |     lk      |    lk-lko   |  avg. time  |\n");
cat(" |-------------|-------------|-------------|-------------|\n");
cat("",sprintf("%11g",c(0,lk)),"\n",sep=" | ")
t0 = proc.time()	
while(abs(lk-lko)/abs(lk)>tol & it<maxit){
	it = it+1; lko = lk
	lao = la; pivo = piv; Phio = Phi; Fc1o = Fc1
# E-step
	W = Fj1/fm
	W1 = PP1*array(W,c(n,k1,k2,TT))
	W2 = PP2*array(W,c(n,k1,k2,k2))
# M-step
	if(k1>1) la = colSums(W)/n
	if(k2>1){
  	  	if(k1==1){
   	   		Z1 = colSums(W1[,1,,1])	
   	   		Z2 = apply(W2,c(3,4),sum)
    	}else{
    		Z1 = apply(W1[,,,1],3,sum)
    		Z2 = apply(W2,c(3,4),sum)
    	}
    	if(sta==0){
			piv = Z1/n
	    	Pi = Z2; Pi = Pi/rowSums(Pi)
		} 	    	
		if(sta==1 || sta==3){
			if(it == 1){
		        ga = optim(lk_stat,par=ga,gr=NULL,Z1,Z2,sta,method="Nelder-Mead",control=list(reltol=10^-12))$par
			}else{
		        ga = optim(lk_stat,par=ga,gr=dlk_stat1,Z1,Z2,sta,method="BFGS",control=list(reltol=10^-12))$par
			} 
	        out = lk_stat(ga,Z1,Z2,sta,out=TRUE)
	        piv = out$rho
	        Pi = out$Pi
	    }
		if(sta==2){
			piv = Z1/n
		    ga = (sum(Z2)-sum(diag(Z2)))/((k2-1)*sum(Z2))
		    Pi = matrix(ga,k2,k2)+diag(k2)*(1-k2*ga)
	    }	    
  	}
# update regreggion parameters (be1, si2, be2)
	W1v = array(aperm(W1,c(1,4,2,3)),c(n*TT,k1,k2))
	NUM = rep(0,nbe); DEN = matrix(0,nbe,nbe)
	for(u in 1:k1) for(v in 1:k2){
		NUM = NUM+XXv[,,u,v]%*%(W1v[,u,v]*Y1v)
		DEN = DEN+XXv[,,u,v]%*%(XXtv[,,u,v]*W1v[,u,v])
	}
	if(rcond(DEN)>10^-15) be1 = as.vector(solve(DEN)%*%NUM)
	Muv = array(0,c(n*TT,k1,k2))
	for(u in 1:k1) for(v in 1:k2) Muv[,u,v] = XXtv[,,u,v]%*%be1
	si2 = sum(W1v*(Y1v-Muv)^2)/sum(Tv)
	flag = TRUE
	while(flag){
		WPQ = W1v*Pv*(1-Pv)
		NUM = rep(0,nbe); DEN = matrix(0,nbe,nbe)
		for(u in 1:k1) for(v in 1:k2){
			NUM = NUM+XXv[,,u,v]%*%(W1v[,u,v]*(Y21v-Pv[,u,v]))
			DEN = DEN+XXv[,,u,v]%*%(XXtv[,,u,v]*WPQ[,u,v])
		}
		if(rcond(DEN)>10^-15){
			dbe2 = as.vector(solve(DEN)%*%NUM)
			mdbe2 = max(abs(dbe2))
			if(mdbe2>0.5) dbe2 = dbe2/mdbe2*0.5
			while(max(be2+dbe2)-min(be2+dbe2)>20) dbe2 = dbe2/2 
			be2 = be2+dbe2
			if(max(abs(dbe2))<10^-6) flag = FALSE
		}else{
			flag = FALSE
		}
		if(it>1){
			flag = FALSE
		}else{
			for(u in 1:k1) for(v in 1:k2) Pv[,u,v] = expit(XXtv[,,u,v]%*%be2)
		}	
	}
# update regreggion parameters (de)
	if(miss){
		flag = TRUE
		while(flag){
			NUM = DEN = 0
			for(u in 1:k1) for(v in 1:k2){
				NUM = NUM+ZZv[,,u,v]%*%(W1v[,u,v]*(D1v-Pmv[,u,v]))
				DEN = DEN+ZZv[,,u,v]%*%(ZZtv[,,u,v]*(W1v[,u,v]*Pmv[,u,v]*(1-Pmv[,u,v])))
			}
			if(rcond(DEN)>10^-15){
				dde = as.vector(solve(DEN)%*%NUM)
				de = de+dde
				if(max(abs(dde))<10^-6) flag = FALSE
			}else{
				flag = FALSE
			}
			if(it>1){
				flag=FALSE
			}else{
				for(u in 1:k1) for(v in 1:k2) Pmv[,u,v] = expit(ZZtv[,,u,v]%*%de)
				Pm = array(Pmv,c(n,TT,k1,k2))
				if(is.null(DD)){
					Pm[Tv==TT,TT,,] = 1
				}else{
					for(i in 1:n) if(DD[i]==0) Pm[i,Tv[i],,] = 1
				}
				Pmv = array(Pm,c(n*TT,k1,k2))
			}		
		}		
	}
# compute likelihood
	si = sqrt(si2)
	for(u in 1:k1) for(v in 1:k2) Pv[,u,v] = expit(XXtv[,,u,v]%*%be2)
	Qv = 1-Pv
	for(u in 1:k1) for(v in 1:k2) Phi[,,u,v] = dnorm(Y1v,Muv[,u,v],si)*(Y21v*Pv[,u,v]+Y20v*Qv[,u,v])
	if(miss){
		for(u in 1:k1) for(v in 1:k2) Pmv[,u,v] = expit(ZZtv[,,u,v]%*%de)
		Pm = array(Pmv,c(n,TT,k1,k2))
		if(is.null(DD)){
			Pm[Tv==TT,TT,,] = 1
		}else{
			for(i in 1:n) if(DD[i]==0) Pm[i,Tv[i],,] = 1
		}
		Pmv = array(Pm,c(n*TT,k1,k2))
		Qm = 1-Pm
	}
	for(i in 1:n) for(u in 1:k1){
		if(miss){
			o = .Fortran("BWforback2", Tv[i], k2, t(Phi[i,1:Tv[i],u,]), t(Pm[i,1:Tv[i],u,]), piv, Pi, lk=0,
			             Pp1=matrix(0,k2,Tv[i]), Pp2=array(0,c(k2,k2,Tv[i])))
		}else{
			o = .Fortran("BWforback", Tv[i], k2, t(Phi[i,1:Tv[i],u,]), piv, Pi, lk=0, 
			             Pp1=matrix(0,k2,Tv[i]), Pp2=array(0,c(k2,k2,Tv[i])))
		}	
	    Fc1[i,u] = exp(o$lk); PP1[i,u,,1:Tv[i]] = o$Pp1
	  	if(k2>1) PP2[i,u,,] = apply(o$Pp2,c(1,2),sum) 
	}
  if(k1==1) Fj1 = Fc1 else Fj1 = Fc1%*%diag(la)
	fm = rowSums(Fj1)
  if(min(fm)<10^-300) print("units with no likelihood!")
	fm = pmax(fm,10^-300)
	lk = sum(log(fm))
# disply output	
   	if(it/10 == floor(it/10)){
		avg = (proc.time()-t0)/it
   		cat("",sprintf("%11g",c(it,lk,lk-lko,avg[1])),"\n",sep=" | ")
   	}
	}
	avg = (proc.time()-t0)/it
	if(it/10>floor(it/10)) cat("",sprintf("%11g",c(it,lk,lk-lko,avg[1])),"\n",sep=" | ")
	cat(" |-------------|-------------|-------------|-------------|\n")	
	
# standard errors
if(se_out){
	if(k1==1) lla = NULL else lla = log(la[-1]/la[1])
	if(k2==1){
		lpiv = NULL; lPi = NULL
	}else{
		lpiv = log(piv[-1]/piv[1])
		lPi = NULL
		for(v in 1:k2){
			lPi = c(lPi,log(Pi[v,-v]/Pi[v,v]))	
		}
	}
	if(sta==0) th = c(be1,be2,de,si2,lla,lpiv,lPi)
	if(sta==1 || sta==3) th = c(be1,be2,de,si2,lla,ga)  
	if(miss){
		out0 = comp_lk(th,k1,k2,XX,ZZ,Y,miss,Tv,sta,DD)
	}else{
		out0 = comp_lk(th,k1,k2,XX,NULL,Y,miss,Tv,sta,DD)		
	}
#	print(lk-out0$lk)	
	nth = length(th)
	sc = rep(0,nth); Jobs = matrix(0,nth,nth)
	for(j in 1:nth){
		inc = rep(0,nth); inc[j] = 10^-6
		out1 = comp_lk(th+inc,k1,k2,XX,ZZ,Y,miss,Tv,sta,DD)	
		sc[j] = (out1$lk-out0$lk)*10^6
		Jobs[,j] = (out1$sc-out0$sc)*10^6
	}
#	print(cbind(sc,out0$sc))
	Jobs = -(Jobs+t(Jobs))/2
	if(rcond(Jobs)<10^-15){
		va = diag(ginv(Jobs))	
	}else{
		va = diag(solve(Jobs))
	}
	if(any(va<0)) print("negative values in V")
	se = sqrt(abs(va))
	sebe1 = se[1:nbe]; sebe2 = se[nbe+(1:nbe)]
	if(miss) sede = se[2*nbe+(1:nde)] else sede=NULL
}

# output
if(k1==1) al1u = NULL else al1u = c(0,be1[1:(k1-1)])
if(k2==1) al1v = NULL else al1v = c(0,be1[k1:(k1+k2-2)])
if(k1+k2>2) be1 = be1[-(1:(k1+k2-2))] 
if(k1==1) al2u = NULL else al2u = c(0,be2[1:(k1-1)])
if(k2==1) al2v = NULL else al2v = c(0,be2[k1:(k1+k2-2)])
if(k1+k2>2) be2 = be2[-(1:(k1+k2-2))]
if(miss){
	if(k1==1) gau = NULL else gau = c(0,de[1:(k1-1)])
	if(k2==1) gav = NULL else gav = c(0,de[k1:(k1+k2-2)])
	if(k1+k2>2) de = de[-(1:(k1+k2-2))] 
	np = 2*nbe+1+nde+(k1-1)
}else{
	gau = NULL; gav = NULL; de = NULL
	np = 2*nbe+1+(k1-1)
}
if(sta==0) np = np+(k2^2-1)
if(sta==1) np = np+k2*(k2-1)
if(sta==2) np = np+k2-1+(k2>1)
if(sta==3) np = np+k2*(k2>1)
bic = -2*lk+np*log(n)
# output
if(se_out){
	out = list(al1u=al1u,al1v=al1v,be1=be1,al2u=al2u,al2v=al2v,be2=be2,si2=si2,gau=gau,
    	       gav=gav,de=de,la=la,piv=piv,Pi=Pi,lk=lk,np=np,bic=bic,W=W,sebe1=sebe1,sebe2=sebe2,sede=sede)
}else{
	out = list(al1u=al1u,al1v=al1v,be1=be1,al2u=al2u,al2v=al2v,be2=be2,si2=si2,gau=gau,
    	       gav=gav,de=de,la=la,piv=piv,Pi=Pi,lk=lk,np=np,bic=bic,W=W)
}
	
}
#-------------------------------------------------------------------------------
lk_stat <- function(ga,Z1=NULL,Z2=NULL,sta=1,out=FALSE){

# sta = 3 for constant off-diagonal elements in each row	
# logit parametrization for the transition matrix
  k = length(ga)
  if(sta==1) k = round((sqrt(1+4*k)+1)/2)
  if(sta==3 & k>2) ga = ga%x%rep(1,k-1)
  Ga = matrix(ga,k-1,k)
# set up transition matrix
  if(k==2){
  	piv = exp(ga)/(1+exp(ga))
  	Pi = rbind(c(1-piv[1],piv[1]),c(piv[2],1-piv[2]))
  }else{
    Pi = matrix(0,k,k)
    temp = c(0,Ga[,1]); temp = temp-max(temp)
    Pi[1,] = exp(temp)/sum(exp(temp))
    for(h in 2:(k-1)){
		temp = c(Ga[1:(h-1),h],0,Ga[h:(k-1),h])
        temp = temp-max(temp)
    	Pi[h,] = exp(temp)/sum(exp(temp))
    }
    temp = c(Ga[,k],0); temp = temp-max(temp)
    Pi[k,] = exp(temp)/sum(exp(temp))
  }
# compute strationary probability vector
  u = rep(1,k)/k
  U = rep(1,k)%o%u
  M = Pi+U-diag(k)
#  if(rcond(M)<10^-16) browser()
  rho = t(ginv(M))%*%u
  rho = pmax(10^-100,rho)
#  if(any(is.na(log(rho)))) browser()
# compute minus the log-likelihood
  if(!is.null(Z1) & !is.null(Z2)) lk=Z1%*%log(rho)+sum(Z2*log(Pi)) else lk=NULL
  if(out){
    lk = list(lk=lk,Pi=Pi,rho=rho)
  }else lk = -lk
  lk

}
#--------------------------------------------------------------------------------
fix_output <-function(out){
	
# fix output from est_LM_dropout
	out0 = out
# regression for Y1
	mu1u = as.vector(out0$al1u%*%out0$la)
	mu1v = as.vector(out0$al1v%*%out0$piv)
	indu = order(out0$al1u)
	indv = order(out0$al1v)
	al1uc = out0$al1u[indu]-mu1u 
	al1vc = out0$al1v[indv]-mu1v 
	be1c = out0$be1; be1c[1] = be1c[1]+mu1u+mu1v
	si2 = out0$si2
# regression for Y1
	mu2u = as.vector(out0$al2u%*%out0$la)
	mu2v = as.vector(out0$al2v%*%out0$piv)
	al2uc = out0$al2u[indu]-mu2u 
	al2vc = out0$al2v[indv]-mu2v
	be2c = out0$be2; be2c[1] = be2c[1]+mu2u+mu2v
# regression for D	 
    if(is.null(out0$de)){
    	gauc = gavc = dec = NULL
    }else{
		mu3u = as.vector(out0$gau%*%out0$la)
		mu3v = as.vector(out0$gav%*%out0$piv)
		gauc = out0$gau[indu]-mu3u 
		gavc = out0$gav[indv]-mu3v
		dec = out0$de; dec[1] = dec[1]+mu3u+mu3v
	}
# latent structure
	lac = out0$la[indu]
	pivc = out0$piv[indv]; Pic = out0$Pi[indv,indv]
# output
    out = list(al1uc=al1uc,al1vc=al1vc,be1c=be1c,si2=si2,
			   al2uc=al2uc,al2vc=al2vc,be2c=be2c,
			   gauc=gauc,gavc=gavc,dec=dec,
			   lac=lac,pivc=pivc,Pic=Pic)
	return(out)
	
}
#------------------------------------------------------------
comp_lk <- function(th,k1,k2,XX,ZZ,Y,miss,Tv,sta,DD){	

# preliminaries
	n = dim(Y)[1]; TT = dim(Y)[2]
	nbe = dim(XX)[1]
	if(miss) nde = dim(ZZ)[1] else nde=0
# confrom matrices
	if(miss){
		D1 = matrix(0,n,TT)
		for(i in 1:n) D1[i,Tv[i]] = 1
	}
	XXv = array(XX,c(nbe,n*TT,k1,k2))
	XXtv = aperm(XXv,c(2,1,3,4))
	if(miss){
		ZZv = array(ZZ,c(nde,n*TT,k1,k2))
		ZZtv = aperm(ZZv,c(2,1,3,4))
		D1v = as.vector(D1)
	}
	Y1 = Y[,,1]; Y20 = 1-Y[,,2]; Y21 = Y[,,2]
	for(i in 1:n){
		Tv[i] = max(which(apply(!is.na(Y[i,,]),1,all)))
		if(Tv[i]<TT){
			Y1[i,(Tv[i]+1):TT] = 0
			Y20[i,(Tv[i]+1):TT] = 0
			Y21[i,(Tv[i]+1):TT] = 0
		}
	}
	Y1v = as.vector(Y1)
	Y21v = as.vector(Y21)
	Y20v = as.vector(Y20)
# decompse parameters
	be1 = th[1:nbe]; th = th[-c(1:nbe)]
	be2 = th[1:nbe]; th = th[-c(1:nbe)]
	if(miss){
		de = th[1:nde]; th = th[-c(1:nde)]
	}
	si2 = th[1]; th = th[-1]
	if(k1==1){
		la=1
	}else{
		lla = th[1:(k1-1)]; th = th[-c(1:(k1-1))]
		la = exp(c(0,lla)); la = la/sum(la)
	} 
	if(k2==1){
		piv=1; Pi=1
	}else{
		if(sta==0){
  			lpiv = th[1:(k2-1)]; th = th[-c(1:(k2-1))]
  			piv = exp(c(0,lpiv)); piv = piv/sum(piv)
  			lPi = th
  			Pi = matrix(0,k2,k2)
  			for(v in 1:k2){
  				ind = (v-1)*(k2-1)+(1:(k2-1))
  				Pi[v,(1:k2)[-v]] = exp(lPi[ind])		
  				Pi[v,v] = 1
  				Pi[v,] = Pi[v,]/sum(Pi[v,])		
  			}
    	}
	    if(sta==1 || sta==3){
	    	ga = th
    		out = lk_stat(ga,Z1=NULL,Z2=NULL,sta=sta,out=TRUE)
      		piv = out$rho
      		Pi = out$Pi
    	}
	}
# compute likelihood
	si = sqrt(si2)
	Phi = array(0,c(n,TT,k1,k2))
	Pv = array(0,c(n*TT,k1,k2))
	for(u in 1:k1) for(v in 1:k2) Pv[,u,v] = expit(t(XXv[,,u,v])%*%be2)
	Mu = apply(XX*be1,2:5,sum); P = expit(apply(XX*be2,2:5,sum)); Q = 1-P
	for(u in 1:k1) for(v in 1:k2) Phi[,,u,v] = dnorm(Y1v,Mu[,,u,v],si)*(Y21*P[,,u,v]+Y20*Q[,,u,v])
	if(miss){
		Pmv = array(0,c(n*TT,k1,k2))
		for(u in 1:k1) for(v in 1:k2) Pmv[,u,v] = expit(ZZtv[,,u,v]%*%de)
		Pm = array(Pmv,c(n,TT,k1,k2))
		if(is.null(DD)){
			Pm[Tv==TT,TT,,] = 1
		}else{
			for(i in 1:n) if(DD[i]==0) Pm[i,Tv[i],,] = 1
		}
		Pmv = array(Pm,c(n*TT,k1,k2))
		Qm = 1-Pm
	}
	Fc1 = matrix(0,n,k1); PP1 = array(0,c(n,k1,k2,TT)); PP2 = array(0,c(n,k1,k2,k2))
	for(i in 1:n) for(u in 1:k1){
		if(miss){
			o = .Fortran("BWforback2", Tv[i], k2, t(Phi[i,1:Tv[i],u,]), t(Pm[i,1:Tv[i],u,]), piv, Pi, lk=0,
			             Pp1=matrix(0,k2,Tv[i]), Pp2=array(0,c(k2,k2,Tv[i])))
		}else{
			o = .Fortran("BWforback", Tv[i], k2, t(Phi[i,1:Tv[i],u,]), piv, Pi, lk=0, Pp1=matrix(0,k2,Tv[i]),
		    			 Pp2=array(0,c(k2,k2,Tv[i])))
		}	
    	Fc1[i,u] = exp(o$lk); PP1[i,u,,1:Tv[i]] = o$Pp1
    	if(k2>1) PP2[i,u,,] = apply(o$Pp2,c(1,2),sum) 
	}
	if(k1==1){
  		Fj1 = Fc1; fm = Fj1
	}else{
  		Fj1 = Fc1%*%diag(la)
	  	fm = rowSums(Fj1)
	}
	if(min(fm)<10^-300) print("units with no likelihood!")
	fm = pmax(fm,10^-300)
	lk = sum(log(fm))	
# E-step
	W = Fj1/fm
	W1 = PP1*array(W,c(n,k1,k2,TT))
	W2 = PP2*array(W,c(n,k1,k2,k2))
# M-step
	if(k1==1){
		dla = NULL
	}else{
		dla = colSums(W)-n*la
		dla = dla[-1]
	}
	if(k2==1){
		dpiv = NULL; dPi = NULL
		if(sta==1 | sta==3) dga = NULL
	}else{
  	  	if(k1==1){
   	   		Z1 = colSums(W1[,1,,1])	
   	   		Z2 = apply(W2,c(3,4),sum)
	    }else{
	    	Z1 = apply(W1[,,,1],3,sum)
	    	Z2 = apply(W2,c(3,4),sum)
	    }
      if(sta==0){
  			dpiv = Z1-n*piv; dpiv = dpiv[-1]
	  		dPi = NULL
		  	for(v in 1:k2)dPi = c(dPi,Z2[v,-v]-sum(Z2[v,])*Pi[v,-v])
      }
      if(sta==1 | sta==3) dga = dlk_stat(ga,Z1,Z2,sta)
	}
# update regreggion parameters (be1, si2, be2)
	W1v = array(aperm(W1,c(1,4,2,3)),c(n*TT,k1,k2))
	NUM = rep(0,nbe)
	for(u in 1:k1) for(v in 1:k2){
		NUM = NUM+t(XXtv[,,u,v]*W1v[,u,v])%*%(Y1v-XXtv[,,u,v]%*%be1)/si2
	}
#  browser()
	dbe1 = NUM
	Muv = array(0,c(n*TT,k1,k2))
	for(u in 1:k1) for(v in 1:k2) Muv[,u,v] = XXtv[,,u,v]%*%be1
	dsi2 = sum(W1v*(Y1v-Muv)^2)/(2*si2^2)-sum(Tv)/(2*si2)
	WPQ = W1v*Pv*(1-Pv)
	NUM = rep(0,nbe)
	for(u in 1:k1) for(v in 1:k2){
		NUM = NUM+XXv[,,u,v]%*%(W1v[,u,v]*(Y21v-Pv[,u,v]))
	}
	dbe2 = NUM
# parameters for missing	
	if(miss){
		NUM = 0
		for(u in 1:k1) for(v in 1:k2){
			NUM = NUM+ZZv[,,u,v]%*%(W1v[,u,v]*(D1v-Pmv[,u,v]))
		}
		dde = NUM
	}else{
		dde = NULL
	}
# score vector
	if(sta==0) sc = c(dbe1,dbe2,dde,dsi2,dla,dpiv,dPi)	
	if(sta==1 | sta==3) sc = c(dbe1,dbe2,dde,dsi2,dla,dga)    
# output
	out = list(lk=lk,sc=sc)
}
# --------------------------------------------------------------------
dlk_stat <- function(ga,Z1,Z2,sta=1){
  
  # logit parametrization for the transition matrix
  k = length(ga)
  if(sta==1) k = round((sqrt(1+4*k)+1)/2)
  if(sta==3 & k>2) ga = ga%x%rep(1,k-1)  
  Ga = matrix(ga,k-1,k)
  # set up transition matrix
  if(k==2){
    piv = exp(ga)/(1+exp(ga))
    Pi = rbind(c(1-piv[1],piv[1]),c(piv[2],1-piv[2]))
  }else{
    Pi = matrix(0,k,k)
    temp = c(0,Ga[,1]); temp = temp-max(temp)
    Pi[1,] = exp(temp)/sum(exp(temp))
    for(h in 2:(k-1)){
      temp = c(Ga[1:(h-1),h],0,Ga[h:(k-1),h])
      temp = temp-max(temp)
      Pi[h,] = exp(temp)/sum(exp(temp))
    }
    temp = c(Ga[,k],0); temp = temp-max(temp)
    Pi[k,] = exp(temp)/sum(exp(temp))
  }
  # compute strationary probability vector
  u = rep(1,k)/k
  U = rep(1,k)%o%u
  M = Pi+U-diag(k)
  #  if(rcond(M)<10^-16) browser()
  Mi = ginv(M)
  rho = as.vector(t(Mi)%*%u)
  lrho = log(rho)
  # derivative
  lk = Z1%*%log(rho)
  dlrho = NULL; dlk = NULL
  Ri = diag(1/rho)
  for(h in 1:k){
    G = diag(k)[,-h]
    Om = diag(Pi[h,])-Pi[h,]%o%Pi[h,]
    dlrho = rbind(dlrho,-rho[h]*(t(G)%*%Om%*%Mi%*%Ri))
    lk = lk+Z2[h,]%*%log(Pi[h,])
    dlk = rbind(dlk,t(G)%*%(Z2[h,]-sum(Z2[h,])*Pi[h,]))
  }
  dlk = dlk+dlrho%*%Z1
#  print(dlk)
  if(sta==3 & k>2){
  	Dlk = matrix(dlk,k-1,k)
  	dlk = colSums(Dlk)
  }
  out = dlk
  
}
# --------------------------------------------------------------------
dlk_stat1 <- function(ga,Z1,Z2,sta=1){
  
  out = -dlk_stat(ga,Z1,Z2,sta)
  return(out)  

}
#-----------------------------------------------------------------------------------------------
expit <- function(x) y = exp(x)/(1+exp(x))
#-----------------------------------------------------------------------------------------------
