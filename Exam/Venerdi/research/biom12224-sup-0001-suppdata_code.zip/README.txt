This .zip file contains the R functions used for the paper
"A discrete time event-history approach to informative drop-out in 
mixed latent Markov models with covariates" by
- F.Bartolucci (University of Perugia, IT)
- A.Farcomeni (Sapienza - University of Rome, IT) 

The main function is est_LM_dropout() that is available by compiling
(using command source()), the file "LM_dropout.R". This function is based on
certain Fortran routines to be compiled according to the operating
system (see R guide). In the .zip file there are also the compiled files
for OSX Snow Leopard (for Mac users). Other users need to compile
the Fortran functions (BWforback.f and BWforback2.f) before compiling "LM_dropout.R".

There are also example files and the corresponding workspace files
with extension .RData. The example files are:
- "example_nmar.R"     : model with NMAR and k1<=3, k2<=3 
- "example_mar.R"      : model with MAR and k1<=3, k2<=3 
- "example_nmar_cons.R": model with NMAR and k1<=3, k2<=3
                         (under the constraint of constant elements in the hidden transition matrix) 
- "example_mar_cons.R" : model with MAR and k1<=3, k2<=3 
                         (under the constraint of constant elements in the hidden transition matrix) 
- "example_nmar_lc.R"  : model with NMAR and k1<=10, k3=1
                         (under the LC model, without time-varying latent variable) 
- "example_mar_lc.R"   : model with MAR and k1<=10, k2=1
                         (under the LC model, without time-varying latent variable)